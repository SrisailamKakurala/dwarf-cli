Dwarf CLI 🚀

A lightweight CLI to generate project boilerplates effortlessly.

📥 Installation

npm install -g dwarf-cli

Or run directly with:

npx dwarf-cli

🚀 Usage

Run the CLI and follow the prompts:

dwarf forge

