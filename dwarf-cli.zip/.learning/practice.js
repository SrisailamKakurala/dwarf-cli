const chalk = require("chalk");

console.log(chalk.green("Success!"));
console.log(chalk.red("Error: Something went wrong!"));
console.log(chalk.blue.bold("Info: Processing..."));